import { Request, Response, NextFunction } from 'express';
import { filesService } from './files.service';
import { sendSuccess, sendCreated, sendNoContent } from '../../common/utils/responseFormatter';
import { sanitizeBody } from '../../common/utils/sanitize-body';

export class FilesController {
    async upload(req: Request, res: Response, next: NextFunction): Promise<void> {
        try {
            // In practice, you'd handle file upload middleware here (multer, etc.)
            const file = await filesService.create(req.context.tenantId, sanitizeBody(req.body));
            sendCreated(res, file, 'File uploaded');
        } catch (e) { next(e); }
    }

    async getMany(req: Request, res: Response, next: NextFunction): Promise<void> {
        try {
            const result = await filesService.getMany(req.context.tenantId, req.query as any);
            sendSuccess(res, result.data, undefined, 200, result.meta);
        } catch (e) { next(e); }
    }

    async getById(req: Request, res: Response, next: NextFunction): Promise<void> {
        try {
            const file = await filesService.getById(req.params.id, req.context.tenantId);
            sendSuccess(res, file);
        } catch (e) { next(e); }
    }

    async update(req: Request, res: Response, next: NextFunction): Promise<void> {
        try {
            const file = await filesService.update(req.params.id, req.context.tenantId, sanitizeBody(req.body));
            sendSuccess(res, file, 'File updated');
        } catch (e) { next(e); }
    }

    async delete(req: Request, res: Response, next: NextFunction): Promise<void> {
        try {
            await filesService.delete(req.params.id, req.context.tenantId);
            sendNoContent(res);
        } catch (e) { next(e); }
    }
}

export const filesController = new FilesController();
